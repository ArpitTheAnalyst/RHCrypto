##version 1.0
### first dish from rockyhandsm2k to github
what does RHCrypto do?
RHCrypto is a unbreakable encryption type made with the formula kiss(keep it simple sweety). it encrypts your msg with once time way or cypher. in this way this msg have trillions of combinations that seems impossible to break without cypher
+ ways to use it:
 one can use it the way of creating a file of some random text sententence and name it 1-10 or so onn 
 keeping the list away from other as a password one can send msg to anyone with the name as the number of cypher used...like 9 
 so the receiver knows which cypher from which text msg...
+ cons:
 it would be as easy to break for others to break the msg as it is for you...only if one gets the list of cypher you made.
 another con is  one can only encrypth the msg containing letters same as the cypher..leading to it cant be more than the words un the cypher or even less
 LAST but not the leas..RHCrypto does not support symbols or signs of your keyboard or others and nor even spacebar...so your msg cant be "hello_world or hello world" it can only be "helloworld" no spaces and symbols  at all.. 

HOW TO USE IT ?
RHCrypto is as easy as login to github... 
+ just final up your one time random cypher
+ enter the cypher first
+ enter your msg of the same length of cypher 
+ voila completed....copy yourmsg and send it
